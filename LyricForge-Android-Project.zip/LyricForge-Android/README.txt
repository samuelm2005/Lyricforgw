LyricForge Android source project (NOT an APK).

Build with Android Studio: Open this folder, allow Gradle sync, Build > Build Bundle(s) / APK(s) > Build APK(s).
APK output: app/build/outputs/apk/debug/app-debug.apk

Alternatively: upload contents to a private GitHub repository; Actions > Build LyricForge APK > Run workflow; download artifact LyricForge-APK. GitHub account and internet required. Keep repository private if desired.

Offline generation is a rule-based draft, NOT a full AI model. AI mode requires a separately configured API. The WebView file origin may prevent some external API services due to CORS; network-based AI generation is not guaranteed in this version.
